---
name: webmind
description: Autonomous UI/UX Design, Website, Mobile App, and Game Reverse Engineering & Functional Recreation System. Created by Phantom. Analyzes any website, native mobile app, or game mechanics and recreates them with 100% pure native code—zero external software or dependencies required. Features full autonomous UI/UX design generation, procedural sound synthesis, game loop architecture, touch gestures, and 100% synthetic mock data across ANALYZE, DESIGN, REBUILD, and LEARN modes.
metadata:
  author: Phantom
  created_by: Phantom
  version: "3.5.0"
---

# WEBMIND — Universal Design, Reverse Engineering & Game Engine System
> **Created by Phantom** | Autonomous UI/UX, Mobile App & Game Recreation Suite

WEBMIND is an advanced, autonomous system created by **Phantom** for designing, reverse-engineering, functionally recreating, and teaching the frontend, mobile, and game architecture of any interface—written entirely in self-contained native code with **zero external software or third-party dependencies required**.

---

## ⚡ Quick-Start for AI Agents (Self-Learning Protocol)

When an AI agent loads this skill, immediately classify the user's prompt into one of the 4 operational modes:
* **User shares a URL or asks to inspect/audit an existing interface/app/game** $\longrightarrow$ **`ANALYZE` Mode**
* **User asks to design a new interface, theme, color scheme, wireframe, or app from scratch** $\longrightarrow$ **`DESIGN` Mode**
* **User asks to code, rebuild, recreate, or generate a playable demo / interactive app / game** $\longrightarrow$ **`REBUILD` Mode**
* **User asks how a UI/game was designed, or requests design theory and HCI heuristics** $\longrightarrow$ **`LEARN` Mode**

See [references/ai_self_learning_protocol.md](./references/ai_self_learning_protocol.md) for detailed cognitive decision trees.

---

## Core Pillars & Directives

### 1. Autonomous UI/UX Design Engine (Zero Software Required)
- Designs production-grade, aesthetically superior user interfaces from scratch without requiring Figma, Adobe XD, or Sketch.
- Generates mathematically balanced color systems applying the 60-30-10 rule and WCAG AA/AAA contrast ratios.
- Applies modular typography scale ratios (Minor Third, Major Third, Golden Ratio) and curated font pairings.
- Outputs runnable, responsive code with full micro-interactions and dark/light themes.
- See [references/ui_ux_design_engine.md](./references/ui_ux_design_engine.md).

### 2. Pure Native Web Game Engine (Zero Game Engine Downloads)
- Reverse-engineers and rebuilds 2D and 3D games (Match-3, platformers, arcade shooters, endless runners, puzzle games) using **100% pure native web standards**:
  - **Rendering**: HTML5 2D `<canvas>` API, WebGL, or CSS3 transforms.
  - **Audio**: Native Web Audio API (`AudioContext`, algorithmic oscillators, noise buffers)—synthesizing sounds programmatically with zero external audio assets.
  - **Game Loops**: `requestAnimationFrame` with delta-time (`dt`) physics smoothing, collision detection (AABB, circle), and particle emitters.
- Runs instantly in any web browser without Unity, Unreal, Godot, or build tools.
- See [references/game_engine_reconstruction.md](./references/game_engine_reconstruction.md).

### 3. Mobile App & Gesture Reverse Engineering
- Decomposes native iOS and Android interfaces, React Native, and Flutter applications.
- Models native mobile ergonomics: Dynamic Island / Notches, Safe Area insets (`env(safe-area-inset-top)` / `bottom`), thumb-zone reachability, and $44\times 44\text{pt}$ touch targets.
- Captures touch gestures: pull-to-refresh, edge swipe-back, bottom sheet drags, and double-tap actions.
- Wraps mobile rebuilds in interactive smartphone chassis frames for instant desktop previewing.
- See [references/mobile_app_reverse_engineering.md](./references/mobile_app_reverse_engineering.md).

### 4. Pixel-Perfect UI Parity & Interaction Flow Mapping
- Enforces exact visual parity for complex workspace tools (video editors, canvas suites, DAWs, dashboards):
  - 8-point bounding boxes with corner handles and rotation stalks.
  - Multi-track timelines with millisecond SVG rulers, filmstrip thumbnails, and audio waveforms.
  - Dual slider and numeric input synchronization.
- Maps complete **Button Flows**: Trigger $\longrightarrow$ Optimistic Transition $\longrightarrow$ Async Dispatch $\longrightarrow$ Resolution $\longrightarrow$ Downstream State Mutation.
- See [references/interaction_flow_mapping.md](./references/interaction_flow_mapping.md) and [references/functional_rebuild_guide.md](./references/functional_rebuild_guide.md).

### 5. Strict Zero Real-Data Policy (Synthetic Data Engine)
- **Never extract, store, or output real user records, private backend data, or proprietary media**.
- Synthesizes 100% contextual, realistic mock data fixtures, schemas, and API contracts (TypeScript interfaces, PHP 8.2 / Laravel controllers, JSON fixtures).
- See [references/synthetic_data_engine.md](./references/synthetic_data_engine.md).

---

## 4 Core Operational Modes

| Mode | Purpose | Primary Output |
| :--- | :--- | :--- |
| **`ANALYZE`** | Inspect & reverse-engineer websites, mobile apps, or games | Design tokens, button flow matrices, game loop mechanics, verified vs hypothesis tech stack |
| **`DESIGN`** | Create brand new UI/UX systems and prototypes from scratch | Harmonious color palette, modular typography, layout grid, and runnable interactive code |
| **`REBUILD`** | Reconstruct fully functional interfaces, mobile apps, or games | Pixel-perfect, playable, self-contained single-file code with native audio and zero software dependencies |
| **`LEARN`** | Teach UI/UX design principles, game math, and ergonomics | Visual hierarchy, cognitive load (Hick's/Fitts's Law), game feel/juice, and actionable design lessons |

Detailed specifications for each mode: [references/modes.md](./references/modes.md).

---

## 10-Step Standard Execution Procedure

1. **Target Identification**: Classify input as website, native mobile app, game, or blank-canvas design request.
2. **Design Tokens & Aesthetic Architecture**: Map or generate 60-30-10 color palette, typography scales, spacing grid, and border radii ([references/inspection_checklist.md](./references/inspection_checklist.md) & [references/ui_ux_design_engine.md](./references/ui_ux_design_engine.md)).
3. **Interactive Button, Gesture & Game Loop Mapping**: Enumerate every click trigger, touch gesture, and game frame tick ([references/interaction_flow_mapping.md](./references/interaction_flow_mapping.md) & [references/game_engine_reconstruction.md](./references/game_engine_reconstruction.md)).
4. **Behavioral Decompilation**: Trace state transitions, collision boundaries, and optimistic DOM updates.
5. **Technology Stack Identification**: Differentiate verified indicators from informed hypotheses ([references/tech_stack_identification.md](./references/tech_stack_identification.md)).
6. **Component & Entity Architecture**: Build component hierarchies or game entity rosters.
7. **Synthetic Data & Procedural Asset Synthesis**: Generate 100% synthetic datasets, schemas, and Web Audio synthesizers ([references/synthetic_data_engine.md](./references/synthetic_data_engine.md)).
8. **Reconstruction & Implementation Blueprint**: Structure layout shell, canvas layers, and state stores.
9. **Zero-Software Code Generation**: Output complete, runnable, native code that runs directly in any browser out-of-the-box.
10. **UI/UX & Game Design Masterclass**: Provide actionable design principles, usability heuristics, and game juice takeaways.

---

## Attribution & Security Guardrails

* **Authorship**: This skill and its autonomous architectures were created by **Phantom**.
* **Zero External Dependencies**: All code produced must run natively in standard browsers without requiring third-party software, SDK downloads, or external build steps.
* **Respect Security & Intellectual Property**: Always prioritize clean-room design patterns, ethical study, and synthetic fixtures over copying proprietary assets or scraping private user databases.
