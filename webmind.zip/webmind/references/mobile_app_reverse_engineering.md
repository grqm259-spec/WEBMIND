# Mobile Application Reverse Engineering & Gesture Flow Guide

WEBMIND extends its reverse-engineering, state machine decomposition, and functional reconstruction engine to **native and cross-platform mobile applications** (iOS, Android, React Native, Flutter, Swift, Kotlin).

---

## 1. Native Mobile Ergonomics & Safe Areas

Mobile app UIs differ fundamentally from desktop viewports through hardware cutouts, gesture navigation, and physical thumb zones:

```text
┌─────────────────────────────────┐ ◄── Top Status Bar (Time, Battery, Wi-Fi)
│         TOP NOTCH / ISLAND      │ ◄── Dynamic Island / Camera Notch (Safe Area Top)
├─────────────────────────────────┤
│ [Back]    Screen Title    [Act] │ ◄── Navigation Bar (44pt - 56pt)
├─────────────────────────────────┤
│                                 │
│                                 │
│        PRIMARY VIEWPORT         │ ◄── Natural Thumb Reach Zone
│    (Scrollable List / Feed)     │
│                                 │
│                                 │
├─────────────────────────────────┤
│  [Home]  [Search]  [+]  [Me]   │ ◄── Bottom Tab Bar (48pt - 56pt)
├─────────────────────────────────┤
│        ════════════════         │ ◄── Home Indicator Bar (Safe Area Bottom: 34pt)
└─────────────────────────────────┘
```

### Essential Safe Area Tokens
* **iOS Notch / Island Inset:** `pt-11` or `env(safe-area-inset-top)`
* **iOS Home Indicator Bar Inset:** `pb-8` or `env(safe-area-inset-bottom)`
* **Android System Navigation Bar:** Standard 48dp bottom clearance
* **Minimum Touch Target:** Strict $44 \times 44\,\text{pt}$ (iOS HIG) / $48 \times 48\,\text{dp}$ (Material Design 3)

---

## 2. Touch Gestures & Micro-Interaction Trajectories

When reverse-engineering a mobile application, document and model these 7 primary mobile gesture interactions:

| Gesture Type | Trigger & Threshold | Visual Feedback & Transition | Target Component |
| :--- | :--- | :--- | :--- |
| **Edge Swipe Back** | Drag from left edge ($x < 20\,\text{px}$) | Current view slides right ($x \to 100\%$) revealing previous screen with backdrop shadow | Navigation Controller |
| **Pull to Refresh** | Pull down on top of scroll ($y > 60\,\text{px}$) | Circular spinner expands, haptic tick, snaps at $40\,\text{px}$ during fetch | Table / Feed View |
| **Swipe Actions** | Horizontal drag on list item | Reveals hidden actions (Delete, Archive, Pin) with background color reveal | List Cells / Inbox |
| **Bottom Sheet Drag** | Drag down on sheet handle bar | Follows finger velocity, snaps to half-sheet or dismisses below screen | Modal Drawers / Menus |
| **Pinch to Zoom** | 2-finger pinch / spread | Scales matrix from focal origin; snaps back to bounds on release | Image & Video Viewers |
| **Long Press / Context**| Hold touch for $>500\,\text{ms}$ | Element lifts with scale-up and drop-shadow; triggers haptic vibration & context menu | Messages, Icons, Posts |
| **Double Tap Heart** | 2 taps within $300\,\text{ms}$ | Centered heart icon springs up with particle burst, then fades | Social Media Posts |

---

## 3. Mobile Navigation Architectures

1. **Bottom Tab Bar Controller**:
   - 3 to 5 primary destinations.
   - Active icon fill with tint color change + label.
   - Badges (unread notifications) positioned on top-right of tab icon.

2. **Stack Navigation (Push / Pop)**:
   - Breadcrumb navigation with transition animation (Slide from right on iOS, subtle zoom/fade on Android).
   - Sticky header with back chevron and previous screen label.

3. **Segmented Control / Top Tab Bars**:
   - Sliding pill indicator behind active label with spring physics.
   - Horizontal swipe gesture between tab views.

4. **Floating Action Button (FAB) (Material 3)**:
   - Elevated pill or circle in bottom-right corner ($16\,\text{dp}$ margins).
   - Animates on scroll (shrinks to icon-only on downward scroll).

---

## 4. Mobile Component Framework Mapping

| UI Pattern | Swift (iOS) | Jetpack Compose (Android) | React Native | Flutter |
| :--- | :--- | :--- | :--- | :--- |
| **Vertical Feed** | `LazyVStack` | `LazyColumn` | `FlatList` | `ListView.builder` |
| **Bottom Sheet** | `.sheet(isPresented:)` | `ModalBottomSheet` | `@gorhom/bottom-sheet` | `showModalBottomSheet` |
| **Tab Bar** | `TabView` | `NavigationBar` | `@react-navigation/bottom-tabs` | `BottomNavigationBar` |
| **Navigation Stack** | `NavigationStack` | `NavHost` | `@react-navigation/native-stack` | `Navigator` / `GoRouter` |
| **Spring Animation** | `.animation(.spring())` | `spring()` | `react-native-reanimated` | `CurvedAnimation` |
| **Haptic Feedback** | `UIImpactFeedbackGenerator`| `HapticFeedbackConstants` | `expo-haptics` | `HapticFeedback` |
