# Synthetic Data Engine: Zero Real-Data Policy

WEBMIND operates under a strict **Zero Real-Data Policy**. When analyzing or rebuilding any website:

---

## 1. Core Principles

1. **Pure Structural & Behavioral Extraction**:
   - Reverse-engineer layout hierarchies, design tokens, component architecture, state machines, and data schemas.
   - **Never extract, store, or output real user data, private records, customer credentials, or copyrighted proprietary text/media**.

2. **100% Contextual Synthetic Data**:
   - Generate rich, realistic mock datasets that emulate the schema, data types, and edge cases of the target website without copying any actual private or third-party content.
   - Adapt data domains dynamically:
     - E-commerce $\rightarrow$ Synthetic products, realistic prices, SKU numbers, mock stock levels.
     - Social / Chat $\rightarrow$ Synthetic avatars (Unsplash open avatars), fictional handles, diverse status messages.
     - Media / Streaming $\rightarrow$ Royalty-free placeholders, synthetic metadata (duration, categories, ratings).
     - Financial / Dashboard $\rightarrow$ Synthesized charts, randomized metric cards, formatted currency.

---

## 2. Full-Stack Data Contracts & Schemas

WEBMIND bridges frontend UI with clean backend contracts. When providing rebuild architectures, output synthetic data contracts across popular paradigms:

### A. TypeScript Data Interfaces
```typescript
export interface SyntheticUser {
  id: string;
  name: string;
  handle: string;
  avatarUrl: string;
  status: 'online' | 'idle' | 'dnd' | 'offline';
  role: 'admin' | 'moderator' | 'member';
  joinedAt: string;
}
```

### B. PHP / Laravel Mock Handlers & Migrations
When PHP data handling is requested or detected, generate clean PHP 8.x contracts, PDO handlers, or Laravel Eloquent model / migration blueprints:

```php
<?php
// Mock Data Controller / Route Handler (PHP 8.2+)
namespace App\Http\Controllers;

class ChannelMessageController
{
    public function index(string $channelId): array
    {
        // Return structured synthetic payload
        return [
            'status' => 'success',
            'channel' => htmlspecialchars($channelId),
            'messages' => [
                [
                    'id' => 'msg_' . bin2hex(random_bytes(4)),
                    'author' => 'SyntheticDev',
                    'avatar' => 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80',
                    'content' => 'Reconstructed state machine verified with synthetic fixtures.',
                    'timestamp' => date('Y-m-d H:i:s'),
                    'reactions' => ['👍' => 4, '🚀' => 7]
                ]
            ]
        ];
    }
}
```

### C. Client-Side Mock Data Engine
Always provide self-generating fixtures for immediate execution in browser demos so interfaces never appear empty or broken.
