# WEBMIND Operational Modes Reference
> **Created by Phantom** | WEBMIND Core Engine

WEBMIND operates across four specialized operational modes. Each mode tailors the output depth, format, and priorities according to the user's objective.

---

## 1. ANALYZE Mode (System Decomposition & Inspection)

**Focus**: Thorough reverse-engineering, component decomposition, gesture tracking, game loop analysis, and observable architecture inspection.

### Standard Output Structure
1. **Executive Snapshot**:
   - Platform classification (Web Application, Native Mobile App, 2D/3D Game).
   - Core visual aesthetic and user journey.
2. **Design Tokens & Visual Language**:
   - 60-30-10 color palette with exact hex codes.
   - Typography scale, font pairings, letter-spacing, line-height.
   - Spacing systems, border radii, shadows, and safe area insets (notches, home indicators).
3. **Interactive Flow Matrix & State Machines**:
   - Button flows, touch gestures, state transitions, keyboard shortcuts.
   - For games: Game loop ticks, collision boxes, particle effects, sound cues.
4. **Technology Stack Identification**:
   - Clearly separated into `[VERIFIED]` facts vs `[HYPOTHESIS]` inferences.

---

## 2. DESIGN Mode (Autonomous UI/UX Design from Scratch)

**Focus**: Creating brand-new, cutting-edge UI/UX systems, wireframes, component libraries, and interactive prototypes directly in code—with zero external design software (no Figma, Photoshop, or Sketch needed).

### Standard Output Structure
1. **Design Concept & Archetype**:
   - Aesthetic direction (e.g., Neo-Brutalist, Cyberpunk, Luxury Minimal, Enterprise Clean, Retro Arcade).
2. **Design System Specification**:
   - Palette Tokens (Dominant, Secondary, Accent, Semantic).
   - Modular Typography Scale with musical interval ratio.
   - Component Spacing Grid (8pt baseline).
3. **Runnable, Interactive Prototype**:
   - Self-contained, single-file HTML5/CSS/JS implementation.
   - Interactive components (working navbars, responsive layouts, active states, light/dark themes).

---

## 3. REBUILD Mode (Pixel-Perfect Functional Reconstruction)

**Focus**: Functional reconstruction with working code, state handling, mobile shells, and zero-software playable games.

### Reconstruction Standards
- **Functionality First**: Interfaces must respond to user actions. Tabs switch, forms validate, dropdowns open, and games are fully playable with keyboard, mouse, or touch controls.
- **Zero Software / Native Code**: Self-contained HTML5 Canvas, WebGL, CSS3, and native Web Audio API oscillators—no Unity, Godot, or heavy dependencies required.
- **Strict Zero Real-Data Policy**: 100% synthetic, realistic mock data.

---

## 4. LEARN Mode (UI/UX Pedagogy & Design Principles)

**Focus**: UI/UX design education, human-computer interaction (HCI) principles, game design mechanics, and design rationale.

### Standard Output Structure
1. **Visual Hierarchy & Scanning Patterns** (Z-pattern, F-pattern, visual anchors).
2. **Cognitive Load & Usability Heuristics** (Hick's Law, Fitts's Law, Miller's Law).
3. **Affordance & Micro-Interaction Feedback**.
4. **Game Design Mathematics & Juice** (Delta-time smoothing, screen shake, easing curves, particle psychology).
5. **Practical Designer Lessons** (3 to 5 concrete techniques the user can apply immediately).
