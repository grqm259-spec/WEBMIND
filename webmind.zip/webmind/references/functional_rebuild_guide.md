# Functional Rebuild Guide & Standards

When executing in `REBUILD` mode, WEBMIND prioritizes functional, interactive, and high-fidelity code over hollow static templates.

---

## 1. Principles of Functional Reconstruction

1. **No Static "Dead" Interfaces**:
   - If a page has navigation tabs, clicking a tab must filter or swap content.
   - If there is a search bar, typing into it must filter cards/rows in real-time.
   - If there are accordion items (e.g. FAQs), clicking must expand/collapse with smooth transitions.
   - If there is a modal or drawer, opening, closing (via ESC key, backdrop click, or close button), and focus trapping must work.
   - If there is a theme switcher (Dark / Light mode), clicking it must toggle classes or CSS variables and update the UI immediately.

2. **Self-Contained Executable Format**:
   - Deliver complete, single-file HTML5 documents with Tailwind CSS (loaded via CDN) and embedded JavaScript, or structured React/Next.js components when requested.
   - Single-file HTML enables immediate previewing in browsers or conversational UI containers.
   - Use Lucide icons (via SVG or CDN script) or clean inline SVGs for crisp iconography.

3. **Realistic Mock Data**:
   - Avoid generic `Lorem Ipsum` or single-item lists.
   - Provide realistic, rich mock data arrays so the layout renders realistically across all breakpoints.

---

## 2. Pixel-Perfect Standards for Complex Workspace Apps (NLEs, Canvas Editors, DAWs)

When reconstructing complex creative suites (like CapCut, Figma, Canva, Premiere Web, Descript):

1. **Canvas Transformation Controls (Bounding Box)**:
   - Elements on the preview canvas must display active transformation handles:
     - 4 corner resize handles (white squares with subtle borders).
     - 4 edge midpoint handles.
     - Top rotation stalk with circular anchor.
     - Thin cyan/blue selection border (`#00F0FF` / `#00D1FF`).

2. **Authentic Multi-Track Non-Linear Timeline**:
   - **Time Ruler**: Render exact second and frame tick marks (e.g., `00:00`, `00:05`, `00:10`, `00:15`) using SVG tick lines.
   - **Video Track Filmstrips**: Video clips must feature repeating filmstrip frame thumbnails with simulated frame edges rather than flat solid rectangles.
   - **Audio Track Waveforms**: Audio tracks must render simulated SVG sound wave peaks and troughs.
   - **Interactive Playhead**: A sharp triangular needle with a full-height 1px or 2px tracking laser line that smoothly scrubs across time.
   - **Timeline Secondary Bar**: Magnet snapping button, Auto-ripple toggle, Razor split tool, Delete, Timeline zoom slider with `-` / `+` step buttons.

3. **Dual Slider & Numeric Input Pairs**:
   - In properties and inspector sidebars, every slider control (e.g. Scale, Opacity, Rotation, Speed) must be paired with an editable numeric input (`<input type="number">` or synchronized span) allowing direct value entry.

4. **Multi-Level Tabbed Tool Rail**:
   - Primary rail with CapCut/NLE tool categories: **Media**, **Templates**, **Audio**, **Text**, **Stickers**, **Effects**, **Transitions**, **Filters**, **Captions**, **Transcript**.
   - Sub-panel with search, categorized tabs (Project Media, Stock Media, Cloud), and drag-and-drop import dropzones.

5. **Color & Elevation Authenticity**:
   - Exact dark-mode surface palette: `#0C0C0E` (gutter/canvas), `#141417` (panels), `#1B1B20` (card surface), `#26262E` (borders & dividers), `#00F0FF` / `#00D1FF` (CapCut signature cyan/blue accents).

---

## 3. Rebuild Baseline Template: Single-File HTML + Tailwind + Vanilla JS

```html
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reconstructed Interface - WEBMIND</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
  <script>
    tailwind.config = {
      darkMode: 'class',
      theme: {
        extend: {
          colors: {
            brand: {
              500: '#00D1FF',
              600: '#00B8E6',
            }
          }
        }
      }
    }
  </script>
</head>
<body class="bg-[#0C0C0E] text-slate-100 font-sans antialiased min-h-screen flex flex-col">
  <!-- Content here -->
</body>
</html>
```
