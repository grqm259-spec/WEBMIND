# Frontend Technology Identification Guide

When reverse-engineering a target website, WEBMIND must distinguish between verifiable technical evidence and plausible inference. Never state assumptions as facts.

---

## 1. Ground Rules for Reporting

Always separate findings into two categories:

- **`[VERIFIED]`**: Supported by direct, unassailable evidence in the client-side markup, response headers, script tags, global variables, or meta tags.
- **`[HYPOTHESIS / LIKELY]`**: Deduced from heuristics, class naming conventions, asset bundling filenames, or third-party service footprints without explicit proof.

---

## 2. Framework Signatures

| Framework / Technology | Verified Indicators | Likely Indicators |
| :--- | :--- | :--- |
| **Next.js** | `<script id="__NEXT_DATA__">`, `/_next/static/` asset paths, `data-nextjs-scroll-focus-boundary` | Hydration error attributes, specific chunk naming |
| **React** | `data-reactroot`, `_reactListening...` properties on DOM nodes, React DevTools hooks (`__REACT_DEVTOOLS_GLOBAL_HOOK__`) | Minified error strings referencing React documentation URLs |
| **Vue / Nuxt** | `__NUXT__` global object, `data-v-[hash]` scoped CSS attributes, `/_nuxt/` paths | `id="__nuxt"` element |
| **Svelte / SvelteKit** | `class="svelte-[hash]"` attributes, `__sveltekit` scripts | Lightweight DOM structure with minimal wrapper elements |
| **Astro** | `<astro-island>`, `data-astro-cid-[hash]`, `<meta name="generator" content="Astro...">` | Static HTML islands with hydrated interactive widgets |
| **Angular** | `ng-version` attribute on root tag, `_nghost-...`, `_ngcontent-...` | SystemJS chunks, Zone.js script references |
| **Remix** | `window.__remixContext`, `<link rel="modulepreload">` with Remix route filenames | Structured form actions and loader patterns |

---

## 3. Styling & CSS Architecture Signatures

| Styling Paradigm | Verified Indicators | Likely Indicators |
| :--- | :--- | :--- |
| **Tailwind CSS** | Standard utility classes in markup (e.g., `flex items-center justify-between p-4 md:p-6 bg-slate-900 text-white rounded-xl shadow-lg transition-all`) | CSS variable definitions matching Tailwind defaults (`--tw-ring-color`, `--tw-shadow`) |
| **CSS Modules** | Class names formatted as `Component_className__[hash]` (e.g., `Navbar_header__z91kx`) | Modular scoped CSS stylesheets |
| **Styled Components / Emotion** | Classes with `sc-[hash]` or `css-[hash]` prefixes, `<style data-styled="active">` tags | Dynamic runtime `<style>` injection |
| **Vanilla / BEM CSS** | Strict Block-Element-Modifier syntax (e.g., `.c-card__title--featured`) | Single bundled `styles.css` without scoped hashes |
| **UI Component Libraries** | Attributes or class names from Radix UI (`data-radix-...`), Headless UI (`headlessui-state`), Shadcn UI, Material UI (`MuiButton-root`), Ant Design (`ant-btn`) | Standardized accessible ARIA role hierarchies |

---

## 4. Script Bundling & Performance Signatures

- **Vite**: Look for `@vite/client` in development, or rollup/esbuild module chunking patterns.
- **Webpack**: Look for `webpackChunk` arrays on `window` (e.g., `window.webpackChunk_N_E`).
- **Turbopack**: Look for `__turbopack__` references in Next.js builds.
- **Analytics & Tracking**: Script tags pointing to Google Tag Manager (`gtm.js`), Google Analytics (`gtag`), PostHog, Mixpanel, Segment, Hotjar.
- **Hosting / CDN**: Observed in response headers:
  - `Server: Vercel`, `x-vercel-id`
  - `Server: Netlify`, `x-nf-request-id`
  - `Server: cloudflare`, `cf-ray`, `cf-cache-status`
  - `Server: AWS / CloudFront`, `x-amz-cf-id`
