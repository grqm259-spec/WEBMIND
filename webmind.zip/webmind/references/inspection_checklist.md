# Website Inspection & Extraction Checklist

Use this checklist during public surface inspection to ensure comprehensive reverse engineering without missing subtle UI nuances.

---

## 1. Page Shell & Global Layout
- [ ] **Viewport & Container**:
  - Max container width (e.g. `1280px`, `1440px`, or fluid 100%)
  - Side gutters / margins across breakpoints (`px-4 sm:px-6 lg:px-8`)
- [ ] **Navigation Bar**:
  - Positioning: `fixed`, `sticky top-0`, or static in flow
  - Background treatment: Solid, translucent with `backdrop-filter: blur()`, or transparent until scroll
  - Height & vertical alignment: Exact height (e.g., 64px / 4rem)
  - Elements present: Logo/wordmark, primary navigation links, dropdown indicators, search trigger, action CTA, theme toggle, mobile hamburger button
- [ ] **Footer**:
  - Multi-column grid vs stacked layout
  - Newsletter subscription box presence
  - Copyright, privacy/terms links, social icon bar

---

## 2. Design Tokens (Colors, Typography, Spacing)
- [ ] **Color Palette**:
  - Background primary (e.g., `#0f172a` or `#ffffff`)
  - Background secondary / card surface (e.g., `#1e293b` or `#f8fafc`)
  - Text primary (high contrast), text muted/secondary, text tertiary
  - Brand / Primary Accent (hex & RGB/HSL for alpha channels)
  - Border colors & subtle dividing lines
  - Semantic colors (success green, danger red, warning amber, info blue)
- [ ] **Typography**:
  - Heading font family (e.g., Inter, Geist, Plus Jakarta Sans, Outfit, Playfair Display)
  - Body font family
  - Heading scales: Font sizes, line heights, font weights (`font-semibold`, `font-bold`, `font-extrabold`)
  - Tracking/Letter spacing: Negative tracking on large headings (`tracking-tight`), uppercase tracking (`tracking-wider`)
- [ ] **Shape & Shadow**:
  - Border radius system: Subtle (`rounded-md`), modern soft (`rounded-xl`), pill (`rounded-full`)
  - Shadows: Layered subtle ambient shadows vs sharp offset borders (neo-brutalist)
  - Borders: Width (`1px`), color opacity, hover highlights

---

## 3. Interactive Components & Micro-Interactions
- [ ] **Buttons & CTAs**:
  - Primary button: Background, text color, padding, hover brightness/scale, active press effect
  - Secondary / Outline button: Border style, hover fill
  - Ghost / Text button: Underline transition or background tint on hover
  - Icons inside buttons: Position (leading/trailing), spacing, animation on hover (e.g. arrow translating right `group-hover:translate-x-1`)
- [ ] **Form Inputs & Search**:
  - Input container styling: border, background, rounded corners
  - Placeholder style & contrast
  - Focus state: focus ring color, offset, border accent
  - Validation feedback: inline error messages, icons
- [ ] **Cards & Lists**:
  - Card hover transitions: `translate-y-[-2px]`, shadow expansion, border glow
  - Image aspect ratios (`aspect-video`, `aspect-square`, `aspect-[4/3]`)
  - Badges/tags: size, colors, pill shapes

---

## 4. Responsive Breakpoints
- [ ] **Mobile (< 640px)**:
  - Header collapsed into hamburger menu or bottom navigation bar
  - Multi-column grids collapsed to single-column flex/grid
  - Typography scaled down (e.g., H1 drops from 3.5rem to 2.25rem)
  - Touch target sizing (minimum 44x44px for tap targets)
- [ ] **Tablet (640px - 1024px)**:
  - 2-column card layouts
  - Adjusted container padding
- [ ] **Desktop (> 1024px)**:
  - Full horizontal navigation
  - 3 or 4-column feature grids
  - Complex sidebars or split-screen hero layouts
