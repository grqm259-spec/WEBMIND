# Autonomous UI/UX Design Engine & System Generator
> **Created by Phantom** | WEBMIND Core Design System

WEBMIND is not only an analysis and reverse-engineering engine, but a full-spectrum **Autonomous UI/UX Designer**. It generates production-grade, aesthetically superior design systems, wireframes, component libraries, and interactive prototypes directly in code—eliminating the need for Figma, Adobe XD, Photoshop, or external design software.

---

## 1. Algorithmic Color Theory & Palettes

WEBMIND designs harmonious color systems applying proven mathematical color harmonies and strict contrast accessibility (WCAG AA/AAA):

### The 60-30-10 Rule
* **60% Dominant Canvas / Neutral Background**: Sets the mood (e.g. deep slate `#0B0F17`, warm stone `#FAFAF9`, or obsidian `#090A0F`).
* **30% Structural Secondary Surface**: Cards, sidebars, headers, borders (`#151C28` or `#FFFFFF`).
* **10% High-Energy Accent / CTA**: Deliberate focal points (e.g. electric indigo `#6366F1`, vibrant emerald `#10B981`, sunset coral `#FF5E62`).

### Dynamic Color Harmony Formulas
1. **Complementary**: $\theta$ and $(\theta + 180^\circ)$ on the color wheel. High contrast, high energy.
2. **Analogous**: $\theta$, $(\theta + 30^\circ)$, $(\theta - 30^\circ)$. Serene, comfortable, cohesive.
3. **Triadic**: $\theta$, $(\theta + 120^\circ)$, $(\theta + 240^\circ)$. Vibrant and balanced for creative and consumer UIs.
4. **Split-Complementary**: $\theta$, $(\theta + 150^\circ)$, $(\theta + 210^\circ)$. Nuanced contrast without visual clash.

---

## 2. Modular Typography Scaling & Font Pairings

WEBMIND structures typography using strict mathematical musical intervals:

| Scale Ratio | Factor | Best Used For |
| :--- | :--- | :--- |
| **Major Second** | $1.125$ | Compact mobile apps, dense dashboards, code editors |
| **Minor Third** | $1.200$ | Standard SaaS web applications, tablet viewports |
| **Major Third** | $1.250$ | Editorial blogs, consumer websites, marketing pages |
| **Perfect Fourth** | $1.333$ | High-contrast expressive landing pages |
| **Golden Ratio** | $1.618$ | Bold luxury, art-directed portfolios |

### Curated Font Pairings (Self-Contained Web Standards)
* **Modern Clean Tech**: `Inter` / `Geist` + `JetBrains Mono`
* **Bold Gaming / Futuristic**: `Fredoka One` / `Syne` / `Space Grotesk` + `Chakra Petch`
* **Editorial & Luxury**: `Playfair Display` / `Cinzel` + `Plus Jakarta Sans`
* **Enterprise SaaS**: `Plus Jakarta Sans` / `Outfit` + `Roboto Mono`

---

## 3. Ergonomic Layout Grids & Spacing Systems

WEBMIND enforces the **8-Point Baseline Grid**:
* Micro-spacing: `2px`, `4px`, `8px` (icon gaps, badge padding, button text offsets).
* Component-spacing: `12px`, `16px`, `24px` (card padding, input heights, list gaps).
* Macro-spacing: `32px`, `48px`, `64px`, `96px` (section separators, hero margins).

### Cognitive Layout Scanning Paths
* **F-Pattern**: For content-heavy blogs, documentation, search results.
* **Z-Pattern**: For high-conversion landing pages, hero banners with dual CTAs.
* **Thumb Zone Mapping**: For mobile apps, placing high-frequency destructive/submit actions in the bottom natural reach sector ($r = 120\text{px}$ from thumb anchor).

---

## 4. Autonomous Component Architecture

When tasked to design a page, app, or feature, WEBMIND produces a unified component suite:
1. **Atoms**: Buttons (Primary, Secondary, Ghost, Danger), Badges, Avatars, Inputs, Toggles.
2. **Molecules**: Search bars, Card units, Dropdown triggers, Stat counters.
3. **Organisms**: Navigation bars, Hero banners, Interactive Data Grids, Modal Drawers, Media Viewports.
4. **Templates**: Page shells, Dashboard layouts, Mobile device chassis.

All components are written in self-contained, immediately runnable HTML5/Tailwind/JS code with active hover, focus, active, and disabled micro-interactions.
