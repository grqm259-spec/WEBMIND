# Interaction Flow & State Machine Mapping Guide

A core differentiator of WEBMIND is the comprehensive reverse engineering of **interactive button flows**, event cascades, and client-side state machines.

---

## 1. The 5-Stage Button Flow Anatomy

For every interactive control (button, link, trigger, toggle, submission), map its complete behavioral trajectory across 5 phases:

```text
[1. Idle / Affordance] 
       │ (User Action: Click, Keypress, Hover)
       ▼
[2. Optimistic Transition] ──► (Instant visual feedback: spinner, disabled state, ripple)
       │ (Event Handling: Dispatch mock/real network request, mutate client state)
       ▼
[3. Resolution / Transition] 
       │
       ├──► [Success Branch] ──► Render updated UI / Toast / Modal / Route navigation
       └──► [Error Branch]   ──► Visual error banner / Shake animation / Retry state
       ▼
[4. State Persistence] ──► LocalStorage / SessionStorage / URL Query Params / Cookie
       │
       ▼
[5. Downstream Cascade] ──► Enable/disable related buttons, update badge counters
```

---

## 2. Interactive Flow Matrix

When auditing a page or section, produce an **Interactive Flow Matrix**:

| Element / Button | Trigger | Input / Condition | Immediate UI State | Async Behavior | Final Resolution / Mutation |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Primary CTA** (e.g. "Get Started") | `click` | Viewport valid | Button scales down (`active:scale-95`), loading indicator | Navigation dispatch or Modal open | Route push to `/signup` or modal drawer opens |
| **Filter / Tab Button** | `click` | Selected tab ID | Tab active border moves, tab badge updates | Local array filter execution (< 16ms) | DOM updates visible card list |
| **Action Toggle** (e.g. Mute / Bookmark) | `click` | Toggle boolean | Instant icon swap (`mic` $\rightarrow$ `mic-off`), color change | State variable flipped | LocalStorage updated; badge count changed |
| **Form Submit** | `click` / `Enter` | Validated input fields | Button disabled, loading spinner | Synthetic payload dispatch | Success message shown, form fields reset |

---

## 3. Mermaid State Diagrams

Represent complex flows using `stateDiagram-v2` or `flowchart TD` to provide immediate structural clarity.

### Example: Multi-State Button Flow
```mermaid
stateDiagram-v2
    [*] --> Idle
    Idle --> Hover: mouseenter
    Hover --> Idle: mouseleave
    Hover --> ActivePressed: mousedown
    ActivePressed --> Loading: mouseup / click [form valid]
    ActivePressed --> ValidationError: mouseup / click [form invalid]
    
    ValidationError --> Idle: input change
    Loading --> Success: dispatch resolved
    Loading --> ErrorState: dispatch rejected
    
    Success --> Redirecting: 1000ms delay
    ErrorState --> Idle: click retry
```

---

## 4. Reverse-Engineering Event Listeners & Traps

1. **Keyboard Event Traps**:
   - `Escape`: Closes modals, dropdowns, full-screen previews.
   - `Tab` / `Shift+Tab`: Focus trapping within active dialogs.
   - `ArrowUp` / `ArrowDown` / `Enter`: Navigates combobox options and auto-complete dropdowns.
   - `Cmd+K` / `Ctrl+K`: Global command palette triggers.

2. **Scroll & Intersection Listeners**:
   - Sticky navigation transitions (e.g., background blur applied once `window.scrollY > 50`).
   - Infinite scroll triggers (`IntersectionObserver` on sentinel elements).
   - Scroll-spy active link highlighting in sidebars.
