# Pure Native Web Game Engine & Game Recreation Guide
> **Created by Phantom** | WEBMIND Core Engine

This reference details how WEBMIND reverse-engineers, architects, and recreates interactive 2D and 3D games using **pure native web technologies**—zero external software, zero heavy game engine downloads, and zero third-party build tools.

---

## 1. Native Zero-Software Philosophy

WEBMIND requires no Unity, Unreal, Godot, or external frameworks to build rich, playable games. Everything runs natively in any modern browser using standard web APIs:

1. **Rendering**: HTML5 2D `<canvas>` API, WebGL, or CSS 3D transforms.
2. **Audio**: Native Web Audio API (`AudioContext`, oscillators, noise buffers, gain envelopes)—no external `.mp3`/`.wav` asset dependencies required.
3. **Loop Mechanics**: `requestAnimationFrame` with delta-time (`dt`) physics smoothing.
4. **Input Handling**: Universal pointer events (mouse, touch, stylus) and keyboard listeners.

---

## 2. Universal Game Loop Architecture

Every game rebuilt by WEBMIND follows a deterministic, state-driven game loop:

```javascript
class NativeGameEngine {
  constructor(canvasId) {
    this.canvas = document.getElementById(canvasId);
    this.ctx = this.canvas.getContext('2d');
    this.lastTime = 0;
    this.state = 'START'; // START, PLAYING, PAUSED, GAMEOVER
    this.entities = [];
    this.particles = [];
  }

  start() {
    this.lastTime = performance.now();
    requestAnimationFrame(this.loop.bind(this));
  }

  loop(currentTime) {
    const dt = Math.min((currentTime - this.lastTime) / 1000, 0.1); // clamp dt
    this.lastTime = currentTime;

    if (this.state === 'PLAYING') {
      this.update(dt);
    }
    this.render();

    requestAnimationFrame(this.loop.bind(this));
  }

  update(dt) {
    // 1. Process player input
    // 2. Update entities & physics
    // 3. Collision detection
    // 4. Update particle effects & screen shake
    // 5. Check victory / defeat conditions
  }

  render() {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    // Draw background, entities, particles, and HUD overlay
  }
}
```

---

## 3. Procedural Audio Synthesizer (Native Web Audio API)

WEBMIND synthesizes all game sound effects algorithmically. No external sound files need to be downloaded or hosted:

```javascript
class SoundFX {
  constructor() {
    this.ctx = null;
  }

  init() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    }
  }

  // Jump / Pop sound (frequency sweep up)
  playJump() {
    this.init();
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(150, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(600, this.ctx.currentTime + 0.15);
    gain.gain.setValueAtTime(0.3, this.ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.01, this.ctx.currentTime + 0.15);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.15);
  }

  // Explosion / Crash (noise buffer + filter sweep down)
  playExplosion() {
    this.init();
    const bufferSize = this.ctx.sampleRate * 0.3;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(800, this.ctx.currentTime);
    filter.frequency.exponentialRampToValueAtTime(50, this.ctx.currentTime + 0.3);
    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.5, this.ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.01, this.ctx.currentTime + 0.3);
    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.ctx.destination);
    noise.start();
  }

  // Coin / Match / Success Chime (Two-tone arpeggio)
  playCoin() {
    this.init();
    [523.25, 659.25, 783.99].forEach((freq, i) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime + i * 0.08);
      gain.gain.setValueAtTime(0.2, this.ctx.currentTime + i * 0.08);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + i * 0.08 + 0.2);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(this.ctx.currentTime + i * 0.08);
      osc.stop(this.ctx.currentTime + i * 0.08 + 0.2);
    });
  }
}
```

---

## 4. Collision Detection Algorithms

1. **Axis-Aligned Bounding Box (AABB)** (Fast rectangular check):
   ```javascript
   function checkAABB(a, b) {
     return (
       a.x < b.x + b.width &&
       a.x + a.width > b.x &&
       a.y < b.y + b.height &&
       a.y + a.height > b.y
     );
   }
   ```
2. **Radial / Circle Collision** (Smooth round checks, balls, bullets):
   ```javascript
   function checkCircle(c1, c2) {
     const dx = c1.x - c2.x;
     const dy = c1.y - c2.y;
     const dist = Math.hypot(dx, dy);
     return dist < (c1.radius + c2.radius);
   }
   ```
3. **Grid-Based Spatial Partitioning** (For tile maps, Match-3, Tetris, Snake):
   - Fast $O(1)$ coordinate lookup `board[row][col]`.

---

## 5. Particle System Engine

Particles give games immediate visual juice and tactile reward. WEBMIND embeds lightweight particle emitters:

```javascript
class ParticleEmitter {
  constructor() {
    this.particles = [];
  }

  burst(x, y, color, count = 20) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 150 + 50;
      this.particles.push({
        x, y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        color,
        size: Math.random() * 5 + 3,
        alpha: 1.0,
        life: 1.0,
        decay: Math.random() * 1.5 + 1.0
      });
    }
  }

  update(dt) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.life -= p.decay * dt;
      p.alpha = Math.max(0, p.life);
      if (p.life <= 0) {
        this.particles.splice(i, 1);
      }
    }
  }

  draw(ctx) {
    this.particles.forEach(p => {
      ctx.save();
      ctx.globalAlpha = p.alpha;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    });
  }
}
```
